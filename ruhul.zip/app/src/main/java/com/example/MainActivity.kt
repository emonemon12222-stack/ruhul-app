package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.model.ChatRoom
import com.example.service.Services
import com.example.ui.screens.CallingOverlay
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainTabContainer
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var selectedRoom by remember { mutableStateOf<ChatRoom?>(null) }
                val currentUser by Services.FirebaseAuth.currentUser.collectAsState()

                Box(modifier = Modifier.fillMaxSize()) {
                    if (currentUser == null) {
                        // User needs to authenticate via Phone + OTP (Firebase Sim)
                        LoginScreen(
                            onLoginSuccess = {
                                // Handled automatically since currentUser state will update
                            }
                        )
                    } else {
                        // Core Messaging Application Screens
                        AnimatedContent(
                            targetState = selectedRoom,
                            transitionSpec = {
                                if (targetState != null) {
                                    // Slide in details screen
                                    slideInHorizontally { width -> width } + fadeIn() togetherWith
                                    slideOutHorizontally { width -> -width } + fadeOut()
                                } else {
                                    // Slide out details back to list
                                    slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                    slideOutHorizontally { width -> width } + fadeOut()
                                }
                            },
                            label = "MainScreenNavigation"
                        ) { activeRoom ->
                            if (activeRoom != null) {
                                ChatDetailScreen(
                                    room = activeRoom,
                                    onBack = { selectedRoom = null }
                                )
                            } else {
                                MainTabContainer(
                                    onLogout = { selectedRoom = null },
                                    onSelectRoom = { selectedRoom = it }
                                )
                            }
                        }
                    }

                    // --- WebRTC / Agora Calling UI Layer ---
                    // This floats seamlessly over all screens when a call goes active/ringing
                    CallingOverlay()
                }
            }
        }
    }
}
