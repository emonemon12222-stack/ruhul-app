package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import coil.compose.AsyncImage
import com.example.model.ChatRoom
import com.example.model.Story
import com.example.model.VoiceClubRoom
import com.example.service.Services
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTabContainer(
    onLogout: () -> Unit,
    onSelectRoom: (ChatRoom) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Chats, 1: Voice Club, 2: Contacts
    var isMeProfileOpen by remember { mutableStateOf(false) } // Extra state for Screen 3 'Me'
    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    
    // Dialog triggers
    var isAddContactOpen by remember { mutableStateOf(false) }
    var isStoryViewerOpen by remember { mutableStateOf(false) }
    var activeViewingStory by remember { mutableStateOf<Story?>(null) }
    var isDataSavedDashboardOpen by remember { mutableStateOf(false) }

    val currentUser by Services.FirebaseAuth.currentUser.collectAsState()
    val chatRooms by Services.FirebaseFirestore.rooms.collectAsState()
    val stories by Services.FirebaseCloudStorage.stories.collectAsState()
    val voiceRooms by Services.VoiceClubService.rooms.collectAsState()
    val dataSavedMb by Services.DataSavedTracker.savedDataMegaBytes.collectAsState()

    val totalUnreadCount = remember(chatRooms) {
        chatRooms.sumOf { it.unreadCount }
    }

    // Story viewer automatic closure simulation
    LaunchedEffect(isStoryViewerOpen) {
        if (isStoryViewerOpen && activeViewingStory != null) {
            delay(4000) // close story after 4s
            isStoryViewerOpen = false
            activeViewingStory = null
        }
    }

    Scaffold(
        topBar = {
            if (!isMeProfileOpen) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ImoDarkSurface)
                ) {
                    // Top Bar Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .windowInsetsPadding(WindowInsets.statusBars),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // User Profile Clickable Avatar
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable { isMeProfileOpen = true }
                                .testTag("top_bar_profile_avatar")
                        ) {
                            Box(contentAlignment = Alignment.BottomEnd) {
                                Card(
                                    shape = CircleShape,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    AsyncImage(
                                        model = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
                                        contentDescription = "My Profile",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(ImoGreenOnline)
                                        .border(1.5.dp, ImoDarkSurface, CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "RUHUL",
                                color = ImoTextPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // Top bar secondary tools (Search toggle / Live Rooms notification)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { isSearchActive = !isSearchActive }) {
                                Icon(
                                    imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = ImoBlueAccent
                                )
                            }
                            IconButton(onClick = { isAddContactOpen = true }) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "Add Contact", tint = ImoBlueAccent)
                            }
                        }
                    }

                    // Tabs row
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = ImoDarkSurface,
                        contentColor = ImoBlueAccent,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = ImoBlueAccent,
                                height = 3.dp
                            )
                        }
                    ) {
                        // Chat Tab
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "CHATS",
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedTab == 0) ImoBlueAccent else ImoTextSecondary
                                    )
                                    if (totalUnreadCount > 0) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .background(ImoRedUnread)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = totalUnreadCount.toString(),
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.testTag("tab_chats")
                        )

                        // Voice Club Tab
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = {
                                Text(
                                    "VOICE CLUB",
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedTab == 1) ImoBlueAccent else ImoTextSecondary
                                )
                            },
                            modifier = Modifier.testTag("tab_voice_club")
                        )

                        // Contacts Tab
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = {
                                Text(
                                    "CONTACTS",
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedTab == 2) ImoBlueAccent else ImoTextSecondary
                                )
                            },
                            modifier = Modifier.testTag("tab_contacts")
                        )
                    }
                }
            }
        },
        containerColor = ImoDarkBg,
        bottomBar = {
            if (!isMeProfileOpen) {
                // Bottom bar requested content: Data Saved Counter, Search icon, Floating '+' button (represented here in layout)
                Surface(
                    color = ImoDarkSurface,
                    border = BorderStroke(0.5.dp, ImoBorder),
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Data Saved widget (Interactive click)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(ImoBlueMuted.copy(alpha = 0.6f))
                                .clickable { isDataSavedDashboardOpen = true }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("data_saved_indicator")
                        ) {
                            Icon(Icons.Default.CloudQueue, contentDescription = "Data Saved", tint = ImoBlueAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = String.format("%.2f MB Saved", dataSavedMb),
                                color = ImoBlueAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Quick Search clicker
                        IconButton(
                            onClick = { isSearchActive = !isSearchActive },
                            modifier = Modifier.testTag("bottom_bar_search")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Search Contacts", tint = ImoTextSecondary)
                        }

                        // Floating action trigger "+"
                        FloatingActionButton(
                            onClick = { isAddContactOpen = true },
                            containerColor = ImoBluePrimary,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("bottom_bar_fab")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Contact/Story", modifier = Modifier.size(24.dp))
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isMeProfileOpen) {
                // Screen 3: User Profile / 'Me' Screen
                MeProfileScreen(
                    currentUser = currentUser,
                    onBack = { isMeProfileOpen = false },
                    onLogout = {
                        Services.FirebaseAuth.logout()
                        onLogout()
                    },
                    dataSavedMb = dataSavedMb,
                    onResetData = { Services.DataSavedTracker.resetSavedData() }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Search Input (If Active)
                    AnimatedVisibility(
                        visible = isSearchActive,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search chats, voice rooms, or contacts...", color = ImoTextMuted, fontSize = 14.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                                .testTag("search_field"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = ImoTextPrimary,
                                unfocusedTextColor = ImoTextPrimary,
                                focusedBorderColor = ImoBlueAccent,
                                unfocusedBorderColor = ImoBorder,
                                focusedContainerColor = ImoDarkCard,
                                unfocusedContainerColor = ImoDarkCard
                            ),
                            shape = RoundedCornerShape(24.dp),
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ImoBlueAccent) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = ImoTextSecondary)
                                    }
                                }
                            }
                        )
                    }

                    // Conditional Content based on selectedTab
                    when (selectedTab) {
                        0 -> {
                            // Screen 1: Chat List Screen
                            ChatListScreen(
                                chatRooms = chatRooms.filter {
                                    it.contactName.contains(searchQuery, ignoreCase = true) ||
                                    it.lastMessage.contains(searchQuery, ignoreCase = true)
                                },
                                stories = stories,
                                onSelectRoom = onSelectRoom,
                                onAddStory = {
                                    // Generate a mock story URL instantly
                                    Services.FirebaseCloudStorage.uploadStory(
                                        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=500"
                                    )
                                },
                                onViewStory = { story ->
                                    activeViewingStory = story
                                    isStoryViewerOpen = true
                                }
                            )
                        }
                        1 -> {
                            // Voice Club Rooms Screen
                            VoiceClubScreen(
                                rooms = voiceRooms.filter {
                                    it.title.contains(searchQuery, ignoreCase = true) ||
                                    it.category.contains(searchQuery, ignoreCase = true)
                                }
                            )
                        }
                        2 -> {
                            // Screen 2: Contacts Screen
                            ContactsScreen(
                                chatRooms = chatRooms.filter {
                                    it.contactName.contains(searchQuery, ignoreCase = true)
                                },
                                onSelectRoom = onSelectRoom
                            )
                        }
                    }
                }
            }

            // --- FULL STORY VIEWER ---
            AnimatedVisibility(
                visible = isStoryViewerOpen && activeViewingStory != null,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                activeViewingStory?.let { story ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black)
                            .clickable {
                                isStoryViewerOpen = false
                                activeViewingStory = null
                            }
                    ) {
                        // Full Background Story Image
                        AsyncImage(
                            model = story.mediaUrl.ifEmpty { "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=500" },
                            contentDescription = "Story Media",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )

                        // Top progress bar overlay
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.4f))
                                .padding(16.dp)
                                .align(Alignment.TopCenter)
                        ) {
                            // Animated horizontal progress line
                            var progressWidth by remember { mutableStateOf(0f) }
                            val animatedProgress by animateFloatAsState(
                                targetValue = 1f,
                                animationSpec = tween(4000, easing = LinearEasing),
                                label = "StoryTimer"
                            )
                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.dp),
                                color = ImoBlueAccent,
                                trackColor = Color.White.copy(alpha = 0.3f),
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Card(
                                    shape = CircleShape,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    AsyncImage(
                                        model = story.userAvatar,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(story.userName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(story.timestamp, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                                }
                            }
                        }

                        Text(
                            text = "Tap anywhere to close story",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 32.dp)
                        )
                    }
                }
            }

            // --- ADD NEW CONTACTS DIALOG ---
            if (isAddContactOpen) {
                var cName by remember { mutableStateOf("") }
                var cPhone by remember { mutableStateOf("") }
                var cId by remember { mutableStateOf("") }
                
                AlertDialog(
                    onDismissRequest = { isAddContactOpen = false },
                    title = { Text("Add RUHUL Contact", color = ImoTextPrimary, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Register a contact directly. Instantly synchronized via Firestore.", color = ImoTextSecondary, fontSize = 12.sp)
                            OutlinedTextField(
                                value = cName,
                                onValueChange = { cName = it },
                                label = { Text("Full Name", color = ImoTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = ImoTextPrimary, unfocusedTextColor = ImoTextPrimary, focusedBorderColor = ImoBlueAccent, unfocusedBorderColor = ImoBorder)
                            )
                            OutlinedTextField(
                                value = cPhone,
                                onValueChange = { cPhone = it },
                                label = { Text("Phone Number", color = ImoTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = ImoTextPrimary, unfocusedTextColor = ImoTextPrimary, focusedBorderColor = ImoBlueAccent, unfocusedBorderColor = ImoBorder)
                            )
                            OutlinedTextField(
                                value = cId,
                                onValueChange = { cId = it },
                                label = { Text("Unique ID", color = ImoTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = ImoTextPrimary, unfocusedTextColor = ImoTextPrimary, focusedBorderColor = ImoBlueAccent, unfocusedBorderColor = ImoBorder)
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                if (cName.isNotEmpty() && cPhone.isNotEmpty()) {
                                    Services.FirebaseFirestore.addContactAndRoom(cName, cPhone, if (cId.isEmpty()) "ruhul_${cPhone.takeLast(4)}" else cId)
                                    isAddContactOpen = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ImoBluePrimary)
                        ) {
                            Text("Add Contact", color = Color.White)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { isAddContactOpen = false }) {
                            Text("Cancel", color = ImoTextSecondary)
                        }
                    },
                    containerColor = ImoDarkSurface
                )
            }

            // --- DATA SAVED DASHBOARD DIALOG ---
            if (isDataSavedDashboardOpen) {
                AlertDialog(
                    onDismissRequest = { isDataSavedDashboardOpen = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudQueue, contentDescription = null, tint = ImoBlueAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("imo Connection Optimizer", color = ImoTextPrimary, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Data Compression active. Audio packets and vector images are optimized in real-time.",
                                color = ImoTextSecondary,
                                fontSize = 13.sp
                            )
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ImoDarkCard),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Total Saved Since Registration:", color = ImoTextMuted, fontSize = 11.sp)
                                    Text(
                                        text = String.format("%.2f MB Saved", dataSavedMb),
                                        color = ImoBlueAccent,
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text("Compressed using WebRTC smart codec ratios.", color = ImoGreenOnline, fontSize = 10.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { isDataSavedDashboardOpen = false },
                            colors = ButtonDefaults.buttonColors(containerColor = ImoBluePrimary)
                        ) {
                            Text("Done", color = Color.White)
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = {
                                Services.DataSavedTracker.resetSavedData()
                            }
                        ) {
                            Text("Reset Counter", color = ImoRedUnread)
                        }
                    },
                    containerColor = ImoDarkSurface
                )
            }
        }
    }
}

// --- SCREEN 1: CHAT LIST SCREEN IMPLEMENTATION ---
@Composable
fun ChatListScreen(
    chatRooms: List<ChatRoom>,
    stories: List<Story>,
    onSelectRoom: (ChatRoom) -> Unit,
    onAddStory: () -> Unit,
    onViewStory: (Story) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        // Horizontal Stories segment
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .padding(vertical = 14.dp)
            ) {
                Text(
                    text = "Stories",
                    color = ImoTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, bottom = 10.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(stories) { story ->
                        StoryBubbleItem(
                            story = story,
                            onAddStory = onAddStory,
                            onViewStory = onViewStory
                        )
                    }
                }
            }
        }

        // Space before list
        item {
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Main Chats Header Label
        item {
            Text(
                text = "Recent chats",
                color = ImoTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
            )
        }

        // Chat Rooms Items List
        if (chatRooms.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No chats found. Add a contact using the '+' button below!", color = ImoTextMuted, textAlign = TextAlign.Center)
                }
            }
        } else {
            items(chatRooms) { room ->
                ChatRoomListItem(
                    room = room,
                    onClick = { onSelectRoom(room) },
                    onCallClick = {
                        Services.WebRTCCallService.startCall(room.contactName, room.contactAvatar, isVideo = false)
                    }
                )
            }
        }
    }
}

@Composable
fun StoryBubbleItem(
    story: Story,
    onAddStory: () -> Unit,
    onViewStory: (Story) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.clickable {
            if (story.isMe && !story.isActive) {
                onAddStory()
            } else {
                onViewStory(story)
            }
        }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(68.dp)
        ) {
            // Glowing Active indicator ring
            if (story.isActive) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .border(2.5.dp, ImoBlueAccent, CircleShape)
                )
            } else if (story.isMe) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .border(1.dp, ImoTextMuted, CircleShape)
                )
            }

            Card(
                shape = CircleShape,
                modifier = Modifier.size(58.dp)
            ) {
                AsyncImage(
                    model = story.userAvatar,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            // Bottom '+' button for adding story
            if (story.isMe && !story.isActive) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(ImoBluePrimary)
                        .align(Alignment.BottomEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Story", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        
        Text(
            text = story.userName,
            color = if (story.isActive) ImoBlueAccent else ImoTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (story.isActive) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.width(68.dp),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ChatRoomListItem(
    room: ChatRoom,
    onClick: () -> Unit,
    onCallClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(ImoDarkSurface)
            .border(0.5.dp, ImoBorder, RoundedCornerShape(0.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar with Online Green indicator
        Box(contentAlignment = Alignment.BottomEnd) {
            Card(
                shape = CircleShape,
                modifier = Modifier.size(48.dp)
            ) {
                AsyncImage(
                    model = room.contactAvatar,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            if (room.isOnline) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(ImoGreenOnline)
                        .border(1.5.dp, ImoDarkSurface, CircleShape)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        // Name & preview column
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = room.contactName,
                    color = ImoTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = room.lastMessageTime,
                    color = ImoTextMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Support Text, Sticker, Link previews requested in Main Chat List
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                ) {
                    if (room.isSticker) {
                        Icon(Icons.Default.Face, contentDescription = "Sticker", tint = ImoBlueAccent, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sticker Sent", color = ImoBlueAccent, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else if (room.isLink) {
                        Icon(Icons.Default.Link, contentDescription = "Link", tint = ImoBlueAccent, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(room.lastMessage, color = ImoTextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else {
                        Text(
                            text = room.lastMessage,
                            color = ImoTextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Unread Badge and call button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (room.unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(ImoRedUnread)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = room.unreadCount.toString(),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }

                    // Direct audio call icon
                    IconButton(
                        onClick = { onCallClick() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("chat_item_call_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Direct Call",
                            tint = ImoBlueAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- SCREEN 2: CONTACTS SCREEN IMPLEMENTATION ---
@Composable
fun ContactsScreen(
    chatRooms: List<ChatRoom>,
    onSelectRoom: (ChatRoom) -> Unit
) {
    var sortByStatus by remember { mutableStateOf(false) }

    val sortedContacts = remember(chatRooms, sortByStatus) {
        if (sortByStatus) {
            chatRooms.sortedByDescending { it.isOnline }
        } else {
            chatRooms.sortedBy { it.contactName }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        // Action Items row (New Contacts, New Group, Call History, Groups, Channels)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    text = "Directory Actions",
                    color = ImoTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, bottom = 10.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { ContactActionItem(icon = Icons.Default.PersonAddAlt, label = "New Contacts") }
                    item { ContactActionItem(icon = Icons.Default.GroupAdd, label = "New Group") }
                    item { ContactActionItem(icon = Icons.Default.History, label = "Call History") }
                    item { ContactActionItem(icon = Icons.Default.Groups, label = "Groups") }
                    item { ContactActionItem(icon = Icons.Default.Campaign, label = "Channels") }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Sorting & Message yourself header Segment
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .clickable { sortByStatus = !sortByStatus }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Sort, contentDescription = null, tint = ImoBlueAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Sort contacts",
                        color = ImoTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (sortByStatus) "by Online Status" else "Alphabetical",
                        color = ImoBlueAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = ImoBlueAccent)
                }
            }
        }

        // 'Message yourself' entry
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .border(0.5.dp, ImoBorder, RoundedCornerShape(0.dp))
                    .clickable {
                        // Select default self communication channel room
                        val selfRoom = ChatRoom(
                            id = "room_me_self",
                            contactName = "Message yourself (Notes)",
                            contactAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
                            lastMessage = "Personal scratchpad",
                            lastMessageTime = "Constant",
                            isOnline = true
                        )
                        onSelectRoom(selfRoom)
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(ImoBlueMuted),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Bookmark, contentDescription = null, tint = ImoBlueAccent)
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text("Message yourself", color = ImoTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Save cloud notes, audio memos, and links safely", color = ImoTextMuted, fontSize = 12.sp)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Contact list item rows
        items(sortedContacts) { room ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .border(0.5.dp, ImoBorder, RoundedCornerShape(0.dp))
                    .clickable { onSelectRoom(room) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Card(
                            shape = CircleShape,
                            modifier = Modifier.size(44.dp)
                        ) {
                            AsyncImage(
                                model = room.contactAvatar,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        if (room.isOnline) {
                            Box(
                                modifier = Modifier
                                    .size(11.dp)
                                    .clip(CircleShape)
                                    .background(ImoGreenOnline)
                                    .border(1.5.dp, ImoDarkSurface, CircleShape)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(room.contactName, color = ImoTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(if (room.isOnline) "Active Now" else "Offline", color = if (room.isOnline) ImoGreenOnline else ImoTextMuted, fontSize = 11.sp)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            Services.WebRTCCallService.startCall(room.contactName, room.contactAvatar, isVideo = false)
                        }
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Audio Call", tint = ImoBlueAccent)
                    }
                    IconButton(
                        onClick = {
                            Services.WebRTCCallService.startCall(room.contactName, room.contactAvatar, isVideo = true)
                        }
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = ImoBlueAccent)
                    }
                }
            }
        }
    }
}

@Composable
fun ContactActionItem(
    icon: ImageVector,
    label: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.width(80.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(ImoBlueMuted),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = ImoBlueAccent, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = ImoTextPrimary,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp
        )
    }
}

// --- VOICE CLUB/ROOMS COMPOSABLE ---
@Composable
fun VoiceClubScreen(
    rooms: List<VoiceClubRoom>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp)
    ) {
        // Decorative Hero club Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ImoBlueMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("imo Voice Clubs", color = ImoBlueAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Live Group Audio", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Join live group chats, speak instantly, or meet voice hosts from all around the globe.", color = ImoTextSecondary, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = ImoBlueAccent, modifier = Modifier.size(32.dp))
                    }
                }
            }
        }

        // Live list
        item {
            Text("Trending Live Rooms", color = ImoTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }

        items(rooms) { room ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ImoDarkSurface),
                border = BorderStroke(1.dp, if (room.isJoined) ImoBlueAccent else ImoBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ImoDarkCard)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(room.category, color = ImoBlueAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Headset, contentDescription = null, tint = ImoGreenOnline, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${room.activeListeners} listening", color = ImoGreenOnline, fontSize = 11.sp)
                            }
                        }

                        if (room.isJoined) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(ImoGreenOnline)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("CONNECTED LIVE", color = ImoGreenOnline, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = room.title,
                        color = ImoTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Card(shape = CircleShape, modifier = Modifier.size(28.dp)) {
                                AsyncImage(
                                    model = room.hostAvatar,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Host: ${room.hostName}", color = ImoTextSecondary, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                Services.VoiceClubService.joinClub(room.id)
                                Services.DataSavedTracker.incrementSavedData(0.24)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (room.isJoined) ImoRedUnread else ImoBluePrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = if (room.isJoined) Icons.Default.Close else Icons.Default.VolumeUp,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (room.isJoined) "Leave" else "Listen Live",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 3: USER PROFILE / 'ME' SCREEN IMPLEMENTATION ---
@Composable
fun MeProfileScreen(
    currentUser: com.example.model.User?,
    onBack: () -> Unit,
    onLogout: () -> Unit,
    dataSavedMb: Double,
    onResetData: () -> Unit
) {
    var isEditingName by remember { mutableStateOf(false) }
    var editNameInput by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var editStatusInput by remember { mutableStateOf(currentUser?.statusText ?: "") }
    var editUniqueIdInput by remember { mutableStateOf(currentUser?.uniqueId ?: "") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ImoDarkBg)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("me_back_button")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = ImoBlueAccent)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text("Me / Settings", color = ImoTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Profile Details Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ImoDarkSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Card(
                            shape = CircleShape,
                            modifier = Modifier
                                .size(90.dp)
                                .clickable { /* change picture */ }
                        ) {
                            AsyncImage(
                                model = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
                                contentDescription = "Profile Pic",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(ImoBluePrimary)
                                .border(1.5.dp, ImoDarkSurface, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isEditingName) {
                        OutlinedTextField(
                            value = editNameInput,
                            onValueChange = { editNameInput = it },
                            label = { Text("Display Name", color = ImoTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = ImoTextPrimary, unfocusedTextColor = ImoTextPrimary, focusedBorderColor = ImoBlueAccent, unfocusedBorderColor = ImoBorder),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = editUniqueIdInput,
                            onValueChange = { editUniqueIdInput = it },
                            label = { Text("Unique ID", color = ImoTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = ImoTextPrimary, unfocusedTextColor = ImoTextPrimary, focusedBorderColor = ImoBlueAccent, unfocusedBorderColor = ImoBorder),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = editStatusInput,
                            onValueChange = { editStatusInput = it },
                            label = { Text("Status Banner", color = ImoTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = ImoTextPrimary, unfocusedTextColor = ImoTextPrimary, focusedBorderColor = ImoBlueAccent, unfocusedBorderColor = ImoBorder),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            TextButton(onClick = { isEditingName = false }) {
                                Text("Cancel", color = ImoRedUnread)
                            }
                            Button(
                                onClick = {
                                    Services.FirebaseAuth.updateProfile(editNameInput, editUniqueIdInput, editStatusInput)
                                    isEditingName = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ImoBluePrimary)
                            ) {
                                Text("Save Profile", color = Color.White)
                            }
                        }
                    } else {
                        Text(
                            text = currentUser?.displayName ?: "No Name Set",
                            color = ImoTextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ID: @${currentUser?.uniqueId ?: "unidentified"}",
                            color = ImoBlueAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = currentUser?.phone ?: "No Phone Set",
                            color = ImoTextSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "\"${currentUser?.statusText ?: "Hey there!"}\"",
                            color = ImoTextMuted,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 12.dp),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { isEditingName = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ImoBlueAccent),
                            border = BorderStroke(1.dp, ImoBlueAccent),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("me_edit_profile_btn")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit profile", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Custom Developer tools for manual overrides
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ImoBlueMuted.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("RUHUL Dev Console", color = ImoBlueAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { Services.DataSavedTracker.incrementSavedData(2.5) },
                            colors = ButtonDefaults.buttonColors(containerColor = ImoBluePrimary),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+2.5MB Saved", fontSize = 10.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                Services.WebRTCCallService.startCall(
                                    "Clara Evans",
                                    "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200",
                                    isVideo = false
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ImoGreenOnline),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Simulate Call", fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
            }
        }

        // Settings Menu Items (Switch Account, Security & Privacy, Settings, Marketplace, imo Voice, Premium, My Files, iBubble, Share app, Help & Feedback)
        item {
            SettingsMenuItem(icon = Icons.Default.SwapHoriz, label = "Switch Account", color = ImoBlueAccent, onClick = onLogout)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.PrivacyTip, label = "Security & Privacy", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.Settings, label = "Settings", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.Storefront, label = "Marketplace", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.KeyboardVoice, label = "RUHUL Voice Premium Features", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.Star, label = "Premium Subscriber Center", color = Color(0xFFFFD700))
        }
        item {
            SettingsMenuItem(icon = Icons.Default.FolderZip, label = "My Files Cloud Sync", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.BubbleChart, label = "iBubble Floating Heads", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.Share, label = "Share app with Friends", color = ImoBlueAccent)
        }
        item {
            SettingsMenuItem(icon = Icons.Default.HelpOutline, label = "Help & Feedback Support", color = ImoTextSecondary)
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun SettingsMenuItem(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(ImoDarkSurface)
            .border(0.5.dp, ImoBorder, RoundedCornerShape(0.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Text(label, color = ImoTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
        Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = ImoTextMuted)
    }
}
