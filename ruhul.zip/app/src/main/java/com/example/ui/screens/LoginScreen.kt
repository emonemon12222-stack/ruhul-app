package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.Services
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {
    var phoneNumber by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ImoDarkBg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Header
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(ImoBlueMuted),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "RUHUL",
                    color = ImoBlueAccent,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = if (!isOtpSent) "Welcome to RUHUL" else "Verify Your Number",
                color = ImoTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = if (!isOtpSent) 
                    "Enter your phone number to initialize authentication via Firebase" 
                    else "Enter the 6-digit code sent to $phoneNumber",
                color = ImoTextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            
            Spacer(modifier = Modifier.height(32.dp))

            errorMessage?.let {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ImoRedUnread.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Text(
                        text = it,
                        color = Color.Red,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            AnimatedContent(
                targetState = isOtpSent,
                transitionSpec = {
                    slideInHorizontally { width -> if (targetState) width else -width } + fadeIn() togetherWith
                    slideOutHorizontally { width -> if (targetState) -width else width } + fadeOut()
                },
                label = "LoginTransition"
            ) { otpSent ->
                if (!otpSent) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Display Name
                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it },
                            label = { Text("Display Name (Optional)", color = ImoTextSecondary) },
                            placeholder = { Text("e.g. John Doe", color = ImoTextMuted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = ImoTextPrimary,
                                unfocusedTextColor = ImoTextPrimary,
                                focusedBorderColor = ImoBlueAccent,
                                unfocusedBorderColor = ImoBorder
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_name_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Phone Input Row with Country Code
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .height(56.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ImoDarkCard)
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "+1 🇺🇸",
                                    color = ImoTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Phone Number", color = ImoTextSecondary) },
                                placeholder = { Text("(555) 019-2834", color = ImoTextMuted) },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = ImoBlueAccent) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = ImoTextPrimary,
                                    unfocusedTextColor = ImoTextPrimary,
                                    focusedBorderColor = ImoBlueAccent,
                                    unfocusedBorderColor = ImoBorder
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_phone_input"),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                if (phoneNumber.isEmpty()) {
                                    errorMessage = "Please enter a valid phone number"
                                    return@Button
                                }
                                isLoading = true
                                errorMessage = null
                                focusManager.clearFocus()
                                
                                Services.FirebaseAuth.sendVerificationCode(
                                    phoneNumber = "+1 $phoneNumber",
                                    onSuccess = {
                                        isLoading = false
                                        isOtpSent = true
                                    },
                                    onFailure = { err ->
                                        isLoading = false
                                        errorMessage = err.message ?: "Authentication failed. Try again."
                                    }
                                )
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = ImoBluePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("login_send_otp_button")
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            } else {
                                Text("Get Verification Code", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = { if (it.length <= 6) otpCode = it },
                            label = { Text("6-Digit OTP Code", color = ImoTextSecondary) },
                            placeholder = { Text("Enter 123456", color = ImoTextMuted) },
                            leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = ImoBlueAccent) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = ImoTextPrimary,
                                unfocusedTextColor = ImoTextPrimary,
                                focusedBorderColor = ImoBlueAccent,
                                unfocusedBorderColor = ImoBorder
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_otp_input"),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(textAlign = TextAlign.Center)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Tip: Enter 123456 to bypass simulation",
                            color = ImoTextMuted,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { isOtpSent = false },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ImoBlueAccent),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                            ) {
                                Icon(Icons.Default.ArrowBack, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Back")
                            }

                            Button(
                                onClick = {
                                    if (otpCode.length != 6) {
                                        errorMessage = "Please enter the full 6-digit verification code"
                                        return@Button
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    focusManager.clearFocus()

                                    Services.FirebaseAuth.verifyOtp(
                                        otpCode = otpCode,
                                        phoneNumber = "+1 $phoneNumber",
                                        displayName = displayName,
                                        onSuccess = {
                                            isLoading = false
                                            onLoginSuccess()
                                        },
                                        onFailure = { err ->
                                            isLoading = false
                                            errorMessage = err.message ?: "Invalid OTP. Please enter 123456."
                                        }
                                    )
                                },
                                enabled = !isLoading,
                                colors = ButtonDefaults.buttonColors(containerColor = ImoBluePrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1.5f)
                                    .height(52.dp)
                                    .testTag("login_verify_otp_button")
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                } else {
                                    Text("Verify & Login", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
