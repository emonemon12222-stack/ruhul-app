package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ImoDarkBg = Color(0xFF121212)
val ImoDarkSurface = Color(0xFF1A1A1A)
val ImoDarkCard = Color(0xFF242424)

val ImoBluePrimary = Color(0xFF0084FF)
val ImoBlueAccent = Color(0xFF00A2FF)
val ImoBlueMuted = Color(0xFF1F355C)

val ImoTextPrimary = Color(0xFFFFFFFF)
val ImoTextSecondary = Color(0xFFA0A0A0)
val ImoTextMuted = Color(0xFF6B6B6B)

val ImoGreenOnline = Color(0xFF34C759)
val ImoRedUnread = Color(0xFFFF3B30)
val ImoBorder = Color(0xFF2C2C2C)
