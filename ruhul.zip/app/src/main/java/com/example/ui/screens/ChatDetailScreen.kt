package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.ChatMessage
import com.example.model.ChatRoom
import com.example.service.Services
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    room: ChatRoom,
    onBack: () -> Unit
) {
    var messageText by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var isStickerDrawerOpen by remember { mutableStateOf(false) }

    // Load initial messages from Firestore Simulation
    LaunchedEffect(room.id) {
        messages.clear()
        messages.addAll(Services.FirebaseFirestore.getLiveMessages(room.id))
        // Scroll to bottom
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val stickersList = listOf(
        Pair("🌸 Hugs", "Warm and snuggly hugs!"),
        Pair("🚀 To the Moon!", "Let's build with Compose!"),
        Pair("✨ Bravo!", "Incredible developer work!"),
        Pair("🎉 Cheers", "Let's celebrate!"),
        Pair("🍕 Foodie", "Pizza party time!"),
        Pair("🎯 Bullseye", "Perfect execution!"),
        Pair("🐱 Meow", "Cute cat vibes!")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            Card(
                                shape = CircleShape,
                                modifier = Modifier.size(38.dp)
                            ) {
                                AsyncImage(
                                    model = room.contactAvatar,
                                    contentDescription = room.contactName,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            if (room.isOnline) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(ImoGreenOnline)
                                        .border(1.5.dp, ImoDarkBg, CircleShape)
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.width(10.dp))
                        
                        Column {
                            Text(
                                text = room.contactName,
                                color = ImoTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (room.isOnline) "online" else "offline",
                                color = if (room.isOnline) ImoGreenOnline else ImoTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ImoBlueAccent)
                    }
                },
                actions = {
                    // Audio call trigger
                    IconButton(
                        onClick = {
                            Services.WebRTCCallService.startCall(room.contactName, room.contactAvatar, isVideo = false)
                        },
                        modifier = Modifier.testTag("chat_audio_call")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Audio Call", tint = ImoBlueAccent)
                    }

                    // Video call trigger
                    IconButton(
                        onClick = {
                            Services.WebRTCCallService.startCall(room.contactName, room.contactAvatar, isVideo = true)
                        },
                        modifier = Modifier.testTag("chat_video_call")
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = ImoBlueAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ImoDarkSurface)
            )
        },
        containerColor = ImoDarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(message)
                }
            }

            // Quick Toolbar (Link shortcut / Stickers toggle)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .border(0.5.dp, ImoBorder, RoundedCornerShape(0.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { isStickerDrawerOpen = !isStickerDrawerOpen }) {
                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = "Toggle Stickers",
                            tint = if (isStickerDrawerOpen) ImoBlueAccent else ImoTextSecondary
                        )
                    }
                    Text(
                        text = "Stickers",
                        color = if (isStickerDrawerOpen) ImoBlueAccent else ImoTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { isStickerDrawerOpen = !isStickerDrawerOpen }
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Share Docs link",
                        color = ImoBlueAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clickable {
                                Services.FirebaseFirestore.sendMessage(
                                    roomId = room.id,
                                    text = "RUHUL iBubble shared documents!",
                                    isLink = true,
                                    linkUrl = "https://ai.studio/build",
                                    linkTitle = "RUHUL Build Docs & API Console"
                                )
                                // Sync local state
                                messages.clear()
                                messages.addAll(Services.FirebaseFirestore.getLiveMessages(room.id))
                                Services.DataSavedTracker.incrementSavedData(0.12)
                                scope.launch {
                                    listState.animateScrollToItem(messages.size - 1)
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Sticker Selector Drawer
            AnimatedVisibility(
                visible = isStickerDrawerOpen,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ImoDarkSurface)
                        .padding(12.dp)
                ) {
                    Text("imo Voice Animated Stickers", color = ImoTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        stickersList.forEach { sticker ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ImoDarkCard),
                                border = BorderStroke(1.dp, ImoBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        Services.FirebaseFirestore.sendMessage(
                                            roomId = room.id,
                                            text = sticker.first,
                                            isSticker = true
                                        )
                                        // Sync local state
                                        messages.clear()
                                        messages.addAll(Services.FirebaseFirestore.getLiveMessages(room.id))
                                        isStickerDrawerOpen = false
                                        Services.DataSavedTracker.incrementSavedData(0.08)
                                        scope.launch {
                                            listState.animateScrollToItem(messages.size - 1)
                                        }
                                    }
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(sticker.first, fontSize = 18.sp)
                                    Text(sticker.second.split(" ").first(), color = ImoTextMuted, fontSize = 9.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Text Field Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ImoDarkSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .windowInsetsPadding(WindowInsets.navigationBars),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    placeholder = { Text("Write your message...", color = ImoTextMuted, fontSize = 14.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ImoTextPrimary,
                        unfocusedTextColor = ImoTextPrimary,
                        focusedBorderColor = ImoBlueAccent,
                        unfocusedBorderColor = ImoBorder,
                        focusedContainerColor = ImoDarkCard,
                        unfocusedContainerColor = ImoDarkCard
                    ),
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (messageText.trim().isNotEmpty()) {
                            Services.FirebaseFirestore.sendMessage(room.id, messageText.trim())
                            messageText = ""
                            messages.clear()
                            messages.addAll(Services.FirebaseFirestore.getLiveMessages(room.id))
                            Services.DataSavedTracker.incrementSavedData(0.02)
                            scope.launch {
                                listState.animateScrollToItem(messages.size - 1)
                            }
                        }
                    })
                )

                Spacer(modifier = Modifier.width(8.dp))

                FloatingActionButton(
                    onClick = {
                        if (messageText.trim().isNotEmpty()) {
                            Services.FirebaseFirestore.sendMessage(room.id, messageText.trim())
                            messageText = ""
                            messages.clear()
                            messages.addAll(Services.FirebaseFirestore.getLiveMessages(room.id))
                            Services.DataSavedTracker.incrementSavedData(0.02)
                            scope.launch {
                                listState.animateScrollToItem(messages.size - 1)
                            }
                        }
                    },
                    containerColor = ImoBluePrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(46.dp)
                        .testTag("chat_send_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val bubbleColor = if (message.isMe) ImoBluePrimary else ImoDarkCard
    val textColor = ImoTextPrimary
    val alignment = if (message.isMe) Alignment.End else Alignment.Start
    val shape = if (message.isMe) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(shape)
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                if (message.isSticker) {
                    // Render Sticker Card
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(message.text, fontSize = 42.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("imo Live Sticker", color = ImoBlueAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (message.isLink) {
                    // Render Link Preview Card
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.25f))
                            .padding(8.dp)
                            .clickable { }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Link, contentDescription = "Link", tint = ImoBlueAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(message.linkTitle ?: "Web Link", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(message.text, color = ImoTextSecondary, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(message.linkUrl ?: "https://imo.im", color = ImoBlueAccent, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                } else {
                    // Standard Text Message
                    Text(
                        text = message.text,
                        color = textColor,
                        fontSize = 15.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(
                        text = message.timestamp,
                        color = if (message.isMe) Color.White.copy(alpha = 0.6f) else ImoTextMuted,
                        fontSize = 9.sp
                    )
                    if (message.isMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.DoneAll, contentDescription = "Read", tint = ImoBlueAccent, modifier = Modifier.size(10.dp))
                    }
                }
            }
        }
    }
}
