package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ImoBluePrimary,
    onPrimary = Color.White,
    primaryContainer = ImoBlueMuted,
    onPrimaryContainer = ImoBlueAccent,
    secondary = ImoBlueAccent,
    onSecondary = Color.White,
    background = ImoDarkBg,
    onBackground = ImoTextPrimary,
    surface = ImoDarkSurface,
    onSurface = ImoTextPrimary,
    surfaceVariant = ImoDarkCard,
    onSurfaceVariant = ImoTextSecondary,
    outline = ImoBorder,
    error = ImoRedUnread,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark theme for gorgeous look
    dynamicColor: Boolean = false, // Use our brand colors
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
