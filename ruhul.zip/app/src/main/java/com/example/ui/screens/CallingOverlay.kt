package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.service.Services
import com.example.ui.theme.*

@Composable
fun CallingOverlay() {
    val callState by Services.WebRTCCallService.currentCallState.collectAsState()
    val callerName by Services.WebRTCCallService.callerName.collectAsState()
    val callerAvatar by Services.WebRTCCallService.callerAvatar.collectAsState()
    val isMuted by Services.WebRTCCallService.isMuted.collectAsState()
    val isVideoEnabled by Services.WebRTCCallService.isVideoEnabled.collectAsState()
    val durationSeconds by Services.WebRTCCallService.callDuration.collectAsState()

    if (callState == Services.WebRTCCallService.CallState.IDLE) return

    val formattedTime = remember(durationSeconds) {
        val mins = durationSeconds / 60
        val secs = durationSeconds % 60
        String.format("%02d:%02d", mins, secs)
    }

    // Pulse animation for ringing and active states
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F1E36),
                        Color(0xFF0C0D14),
                        ImoDarkBg
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("calling_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header stats (Simulating real WebRTC session status)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 24.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (callState == Services.WebRTCCallService.CallState.ACTIVE) ImoGreenOnline else ImoBlueAccent)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (callState) {
                            Services.WebRTCCallService.CallState.CONNECTING -> "WebRTC SDP HANDSHAKE..."
                            Services.WebRTCCallService.CallState.RINGING -> "AGORA PEER RINGING..."
                            Services.WebRTCCallService.CallState.ACTIVE -> "MUTUAL MEDIA STREAM [SECURE]"
                            Services.WebRTCCallService.CallState.DISCONNECTED -> "CALL DISCONNECTED"
                            else -> "IDLE"
                        },
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = callerName,
                    color = ImoTextPrimary,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = when (callState) {
                        Services.WebRTCCallService.CallState.CONNECTING -> "Connecting..."
                        Services.WebRTCCallService.CallState.RINGING -> "Ringing..."
                        Services.WebRTCCallService.CallState.ACTIVE -> formattedTime
                        Services.WebRTCCallService.CallState.DISCONNECTED -> "Ending call..."
                        else -> ""
                    },
                    color = if (callState == Services.WebRTCCallService.CallState.ACTIVE) ImoBlueAccent else ImoTextSecondary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Avatar & Pulsing Rings
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                if (callState == Services.WebRTCCallService.CallState.RINGING || callState == Services.WebRTCCallService.CallState.CONNECTING) {
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .border(2.dp, ImoBlueAccent.copy(alpha = pulseAlpha), CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .scale(pulseScale * 0.9f)
                            .clip(CircleShape)
                            .border(1.dp, ImoBlueAccent.copy(alpha = pulseAlpha * 0.5f), CircleShape)
                    )
                }

                Card(
                    shape = CircleShape,
                    border = BorderStroke(3.dp, ImoBlueAccent),
                    modifier = Modifier.size(140.dp),
                    elevation = CardDefaults.cardColors(containerColor = ImoDarkCard).let { CardDefaults.cardElevation(defaultElevation = 8.dp) }
                ) {
                    AsyncImage(
                        model = callerAvatar.ifEmpty { "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200" },
                        contentDescription = "Caller Avatar",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Live WebRTC Network & Audio Info Pane
            if (callState == Services.WebRTCCallService.CallState.ACTIVE) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Agora Protocol", color = ImoTextMuted, fontSize = 11.sp)
                            Text("WebRTC 1.0 PeerConnection", color = ImoBlueAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Audio Codec", color = ImoTextMuted, fontSize = 11.sp)
                            Text("Opus Stereo (48kHz @ 64kbps)", color = ImoTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Connection Quality", color = ImoTextMuted, fontSize = 11.sp)
                            Text("Excellent (RTT 18ms, Jitter 2ms)", color = ImoGreenOnline, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        if (isVideoEnabled) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Video Stream", color = ImoTextMuted, fontSize = 11.sp)
                                Text("H.264 HD @ 30fps (Muted Placeholder)", color = ImoBlueAccent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            // Controls Panel
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Secondary Controls Row (Mute, Video, Speaker)
                if (callState == Services.WebRTCCallService.CallState.ACTIVE || callState == Services.WebRTCCallService.CallState.RINGING) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 32.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CallControlToggle(
                            isActive = isMuted,
                            activeIcon = Icons.Default.MicOff,
                            inactiveIcon = Icons.Default.Mic,
                            label = "Mute",
                            onClick = { Services.WebRTCCallService.toggleMute() }
                        )

                        CallControlToggle(
                            isActive = isVideoEnabled,
                            activeIcon = Icons.Default.Videocam,
                            inactiveIcon = Icons.Default.VideocamOff,
                            label = "Video",
                            onClick = { Services.WebRTCCallService.toggleVideo() }
                        )

                        var isSpeakerOn by remember { mutableStateOf(false) }
                        CallControlToggle(
                            isActive = isSpeakerOn,
                            activeIcon = Icons.Default.VolumeUp,
                            inactiveIcon = Icons.Default.VolumeDown,
                            label = "Speaker",
                            onClick = { isSpeakerOn = !isSpeakerOn }
                        )
                    }
                }

                // Hang up / Accept main buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (callState == Services.WebRTCCallService.CallState.RINGING) {
                        // Accept Call Button
                        FloatingActionButton(
                            onClick = { Services.WebRTCCallService.acceptIncomingCall() },
                            containerColor = ImoGreenOnline,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(68.dp)
                                .padding(horizontal = 4.dp)
                                .testTag("call_accept_button")
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Accept Call", modifier = Modifier.size(28.dp))
                        }
                        
                        Spacer(modifier = Modifier.width(36.dp))
                    }

                    // Hangup Call Button
                    FloatingActionButton(
                        onClick = { Services.WebRTCCallService.endCall() },
                        containerColor = ImoRedUnread,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(68.dp)
                            .testTag("call_hangup_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "Hang Up",
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CallControlToggle(
    isActive: Boolean,
    activeIcon: ImageVector,
    inactiveIcon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(if (isActive) ImoBluePrimary else Color.White.copy(alpha = 0.08f))
                .border(1.dp, if (isActive) ImoBlueAccent else Color.White.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isActive) activeIcon else inactiveIcon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = if (isActive) ImoBlueAccent else ImoTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
