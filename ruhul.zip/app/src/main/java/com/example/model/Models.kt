package com.example.model

data class User(
    val id: String = "",
    val displayName: String = "",
    val uniqueId: String = "",
    val phone: String = "",
    val avatarUrl: String = "",
    val isOnline: Boolean = false,
    val statusText: String = ""
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val timestamp: String = "",
    val isSticker: Boolean = false,
    val isLink: Boolean = false,
    val linkUrl: String? = null,
    val linkTitle: String? = null,
    val isMe: Boolean = false
)

data class ChatRoom(
    val id: String = "",
    val contactName: String = "",
    val contactAvatar: String = "",
    val lastMessage: String = "",
    val lastMessageTime: String = "",
    val unreadCount: Int = 0,
    val isOnline: Boolean = false,
    val phone: String = "",
    val uniqueId: String = "",
    val isSticker: Boolean = false,
    val isLink: Boolean = false
)

data class Story(
    val id: String = "",
    val userName: String = "",
    val userAvatar: String = "",
    val isMe: Boolean = false,
    val timestamp: String = "",
    val mediaUrl: String = "",
    val isActive: Boolean = true
)

data class VoiceClubRoom(
    val id: String = "",
    val title: String = "",
    val hostName: String = "",
    val hostAvatar: String = "",
    val category: String = "",
    val activeListeners: Int = 0,
    val isJoined: Boolean = false
)
