package com.example.service

import android.util.Log
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object Services {
    private const val TAG = "RuhulServices"

    // --- Firebase Auth Simulation & Placeholder ---
    object FirebaseAuth {
        private val _currentUser = MutableStateFlow<User?>(null)
        val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

        private val _verificationId = MutableStateFlow<String?>(null)
        val verificationId: StateFlow<String?> = _verificationId.asStateFlow()

        init {
            // Pre-authenticate with a default user for a seamless initial UX,
            // but allow switching accounts or logging out.
            _currentUser.value = User(
                id = "me_user_123",
                displayName = "Alex Carter",
                uniqueId = "alex_ruhul_99",
                phone = "+1 (555) 019-2834",
                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
                isOnline = true,
                statusText = "Available"
            )
        }

        fun sendVerificationCode(phoneNumber: String, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
            Log.d(TAG, "FirebaseAuth: sendVerificationCode to $phoneNumber")
            if (phoneNumber.length < 7) {
                onFailure(IllegalArgumentException("Invalid phone number length"))
                return
            }
            _verificationId.value = "verify_session_${UUID.randomUUID()}"
            onSuccess()
        }

        fun verifyOtp(otpCode: String, phoneNumber: String, displayName: String, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
            Log.d(TAG, "FirebaseAuth: verifyOtp $otpCode for $phoneNumber")
            if (otpCode == "123456" || otpCode.length == 6) {
                val newUser = User(
                    id = "user_${UUID.randomUUID()}",
                    displayName = displayName.ifEmpty { "User ${phoneNumber.takeLast(4)}" },
                    uniqueId = "ruhul_${phoneNumber.takeLast(4)}",
                    phone = phoneNumber,
                    avatarUrl = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
                    isOnline = true,
                    statusText = "Hey there! I am using RUHUL."
                )
                _currentUser.value = newUser
                onSuccess()
            } else {
                onFailure(IllegalArgumentException("Invalid verification code. Enter 123456 or any 6-digit number."))
            }
        }

        fun logout() {
            _currentUser.value = null
            _verificationId.value = null
        }

        fun updateProfile(name: String, uniqueId: String, status: String) {
            _currentUser.value = _currentUser.value?.copy(
                displayName = name,
                uniqueId = uniqueId,
                statusText = status
            )
        }
    }

    // --- Firebase Firestore Real-Time Messaging & Cloud Synchronization ---
    object FirebaseFirestore {
        private val _rooms = MutableStateFlow<List<ChatRoom>>(emptyList())
        val rooms: StateFlow<List<ChatRoom>> = _rooms.asStateFlow()

        private val _messages = MutableStateFlow<Map<String, List<ChatMessage>>>(emptyMap())
        
        init {
            // Populate beautiful, realistic initial chat rooms (imo style: support Stickers, voice, links)
            _rooms.value = listOf(
                ChatRoom(
                    id = "room_1",
                    contactName = "Sarah Jenkins",
                    contactAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
                    lastMessage = "Sent a voice message",
                    lastMessageTime = "12:45 PM",
                    unreadCount = 2,
                    isOnline = true,
                    phone = "+1 (555) 234-5678",
                    uniqueId = "sarah_j9"
                ),
                ChatRoom(
                    id = "room_2",
                    contactName = "Liam Thompson",
                    contactAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
                    lastMessage = "Check out this link! 🚀",
                    lastMessageTime = "Yesterday",
                    unreadCount = 0,
                    isOnline = false,
                    phone = "+1 (555) 987-6543",
                    uniqueId = "liam_t_ruhul",
                    isLink = true
                ),
                ChatRoom(
                    id = "room_3",
                    contactName = "Clara Evans (RUHUL Voice)",
                    contactAvatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200",
                    lastMessage = "Sent a gorgeous sticker",
                    lastMessageTime = "Wednesday",
                    unreadCount = 0,
                    isOnline = true,
                    phone = "+1 (555) 345-6789",
                    uniqueId = "clara_voice_club",
                    isSticker = true
                ),
                ChatRoom(
                    id = "room_4",
                    contactName = "Marcus Aurelius",
                    contactAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
                    lastMessage = "The best revenge is to be unlike him who performed the injury.",
                    lastMessageTime = "09/15/26",
                    unreadCount = 0,
                    isOnline = true,
                    phone = "+1 (555) 123-4567",
                    uniqueId = "marcus_philosopher"
                )
            )

            // Setup initial realistic messages
            _messages.value = mapOf(
                "room_1" to listOf(
                    ChatMessage("msg_1_1", "room_1", "Sarah Jenkins", "Hey there! Are you joining the Voice Club room later?", "11:30 AM"),
                    ChatMessage("msg_1_2", "me_user_123", "Alex", "Yes, absolutely! What time does it start?", "11:32 AM", isMe = true),
                    ChatMessage("msg_1_3", "room_1", "Sarah Jenkins", "Around 8:00 PM. We will discuss premium updates.", "11:35 AM"),
                    ChatMessage("msg_1_4", "room_1", "Sarah Jenkins", "Sent a voice message", "12:45 PM")
                ),
                "room_2" to listOf(
                    ChatMessage("msg_2_1", "room_2", "Liam Thompson", "Hello Alex! I found this awesome modern Jetpack Compose theme.", "Yesterday"),
                    ChatMessage("msg_2_2", "room_2", "Liam Thompson", "Check out this link! 🚀", "Yesterday", isLink = true, linkUrl = "https://m3.material.io", linkTitle = "Material Design 3 Layouts & Typography")
                ),
                "room_3" to listOf(
                    ChatMessage("msg_3_1", "room_3", "Clara Evans", "Hi! Try our new animated iBubble features.", "Wednesday"),
                    ChatMessage("msg_3_2", "room_3", "Clara Evans", "Sent a gorgeous sticker", "Wednesday", isSticker = true)
                ),
                "room_4" to listOf(
                    ChatMessage("msg_4_1", "room_4", "Marcus Aurelius", "Very little is needed to make a happy life; it is all within yourself, in your way of thinking.", "09/14/26"),
                    ChatMessage("msg_4_2", "room_4", "Marcus Aurelius", "The best revenge is to be unlike him who performed the injury.", "09/15/26")
                )
            )
        }

        fun getMessagesForRoom(roomId: String): StateFlow<List<ChatMessage>> {
            val list = _messages.value[roomId] ?: emptyList()
            return MutableStateFlow(list).asStateFlow()
        }

        fun getLiveMessages(roomId: String): List<ChatMessage> {
            return _messages.value[roomId] ?: emptyList()
        }

        fun sendMessage(roomId: String, text: String, isSticker: Boolean = false, isLink: Boolean = false, linkUrl: String? = null, linkTitle: String? = null) {
            val formatter = SimpleDateFormat("h:mm a", Locale.getDefault())
            val timeString = formatter.format(Date())
            
            val newMsg = ChatMessage(
                id = "msg_${UUID.randomUUID()}",
                senderId = "me_user_123",
                senderName = FirebaseAuth.currentUser.value?.displayName ?: "Me",
                text = text,
                timestamp = timeString,
                isSticker = isSticker,
                isLink = isLink,
                linkUrl = linkUrl,
                linkTitle = linkTitle,
                isMe = true
            )

            val currentRoomMsgs = _messages.value[roomId]?.toMutableList() ?: mutableListOf()
            currentRoomMsgs.add(newMsg)
            
            val updatedMap = _messages.value.toMutableMap()
            updatedMap[roomId] = currentRoomMsgs
            _messages.value = updatedMap

            // Update rooms list item as well
            val updatedRooms = _rooms.value.map { room ->
                if (room.id == roomId) {
                    room.copy(
                        lastMessage = if (isSticker) "Sent a sticker" else if (isLink) "Shared a link" else text,
                        lastMessageTime = timeString,
                        unreadCount = 0,
                        isSticker = isSticker,
                        isLink = isLink
                    )
                } else {
                    room
                }
            }
            _rooms.value = updatedRooms
            Log.d(TAG, "FirebaseFirestore: Message sent to room $roomId: $text")
        }

        fun addContactAndRoom(name: String, phone: String, uniqueId: String) {
            val newRoomId = "room_${UUID.randomUUID()}"
            val newRoom = ChatRoom(
                id = newRoomId,
                contactName = name,
                contactAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200",
                lastMessage = "Started a conversation",
                lastMessageTime = "Just Now",
                unreadCount = 0,
                isOnline = true,
                phone = phone,
                uniqueId = uniqueId
            )
            _rooms.value = listOf(newRoom) + _rooms.value
            _messages.value = _messages.value.toMutableMap().apply {
                this[newRoomId] = listOf(
                    ChatMessage("msg_init", newRoomId, name, "Hi! Nice to connect with you on RUHUL.", "Just Now")
                )
            }
        }
    }

    // --- Firebase Cloud Storage Simulation ---
    object FirebaseCloudStorage {
        private val _stories = MutableStateFlow<List<Story>>(emptyList())
        val stories: StateFlow<List<Story>> = _stories.asStateFlow()

        init {
            _stories.value = listOf(
                Story(
                    id = "story_me",
                    userName = "My Story",
                    userAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
                    isMe = true,
                    timestamp = "Add story",
                    mediaUrl = "",
                    isActive = false
                ),
                Story(
                    id = "story_1",
                    userName = "Sarah J.",
                    userAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
                    timestamp = "10m ago",
                    mediaUrl = "https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&q=80&w=500",
                    isActive = true
                ),
                Story(
                    id = "story_2",
                    userName = "Liam T.",
                    userAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
                    timestamp = "2h ago",
                    mediaUrl = "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?auto=format&fit=crop&q=80&w=500",
                    isActive = true
                ),
                Story(
                    id = "story_3",
                    userName = "Clara E.",
                    userAvatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200",
                    timestamp = "5h ago",
                    mediaUrl = "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=500",
                    isActive = true
                )
            )
        }

        fun uploadStory(mediaUrl: String) {
            val newStory = Story(
                id = "story_${UUID.randomUUID()}",
                userName = "My Story",
                userAvatar = FirebaseAuth.currentUser.value?.avatarUrl ?: "",
                isMe = true,
                timestamp = "Just Now",
                mediaUrl = mediaUrl,
                isActive = true
            )
            // Replace the previous "me" story or prepend it
            val list = _stories.value.toMutableList()
            // Keep the 'Add Story' button but update story status
            val meStoryIndex = list.indexOfFirst { it.isMe }
            if (meStoryIndex != -1) {
                list[meStoryIndex] = list[meStoryIndex].copy(
                    isActive = true,
                    mediaUrl = mediaUrl,
                    timestamp = "Just Now"
                )
            } else {
                list.add(0, newStory)
            }
            _stories.value = list
            Log.d(TAG, "FirebaseCloudStorage: Story uploaded successfully: $mediaUrl")
        }
    }

    // --- WebRTC & Agora Calling Engine Placeholders ---
    object WebRTCCallService {
        enum class CallState {
            IDLE, RINGING, CONNECTING, ACTIVE, DISCONNECTED
        }

        private val _currentCallState = MutableStateFlow(CallState.IDLE)
        val currentCallState: StateFlow<CallState> = _currentCallState.asStateFlow()

        private val _callerName = MutableStateFlow("")
        val callerName: StateFlow<String> = _callerName.asStateFlow()

        private val _callerAvatar = MutableStateFlow("")
        val callerAvatar: StateFlow<String> = _callerAvatar.asStateFlow()

        private val _isMuted = MutableStateFlow(false)
        val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

        private val _isVideoEnabled = MutableStateFlow(false)
        val isVideoEnabled: StateFlow<Boolean> = _isVideoEnabled.asStateFlow()

        private val _callDuration = MutableStateFlow(0)
        val callDuration: StateFlow<Int> = _callDuration.asStateFlow()

        private var durationTimer: Timer? = null

        fun startCall(contactName: String, contactAvatar: String, isVideo: Boolean = false) {
            _callerName.value = contactName
            _callerAvatar.value = contactAvatar
            _isVideoEnabled.value = isVideo
            _isMuted.value = false
            _callDuration.value = 0

            // Simulate WebRTC Connection Pipeline
            _currentCallState.value = CallState.CONNECTING
            Log.d(TAG, "WebRTC: Initializing PeerConnection & Agora Channel Session.")

            // Move state transition in background
            Timer().schedule(object : TimerTask() {
                override fun run() {
                    if (_currentCallState.value == CallState.CONNECTING) {
                        _currentCallState.value = CallState.RINGING
                        Log.d(TAG, "WebRTC: Agora engine SDP exchange successful. Remote status: Ringing.")
                    }
                }
            }, 1500)

            // Simulate pickup
            Timer().schedule(object : TimerTask() {
                override fun run() {
                    if (_currentCallState.value == CallState.RINGING) {
                        _currentCallState.value = CallState.ACTIVE
                        Log.d(TAG, "WebRTC: Remote accepted call. ICE candidates established. Media stream open.")
                        startDurationTimer()
                    }
                }
            }, 4500)
        }

        fun acceptIncomingCall() {
            if (_currentCallState.value == CallState.RINGING) {
                _currentCallState.value = CallState.ACTIVE
                startDurationTimer()
            }
        }

        fun endCall() {
            Log.d(TAG, "WebRTC: Closing PeerConnection. Releasing Agora Channel.")
            _currentCallState.value = CallState.DISCONNECTED
            stopDurationTimer()
            Timer().schedule(object : TimerTask() {
                override fun run() {
                    _currentCallState.value = CallState.IDLE
                }
            }, 1000)
        }

        fun toggleMute() {
            _isMuted.value = !_isMuted.value
            Log.d(TAG, "WebRTC: Mute toggled to ${_isMuted.value}")
        }

        fun toggleVideo() {
            _isVideoEnabled.value = !_isVideoEnabled.value
            Log.d(TAG, "WebRTC: Video toggled to ${_isVideoEnabled.value}")
        }

        private fun startDurationTimer() {
            stopDurationTimer()
            durationTimer = Timer()
            durationTimer?.scheduleAtFixedRate(object : TimerTask() {
                override fun run() {
                    _callDuration.value += 1
                }
            }, 1000, 1000)
        }

        private fun stopDurationTimer() {
            durationTimer?.cancel()
            durationTimer = null
        }
    }

    // --- Voice Clubs / Audio Stream Rooms Data ---
    object VoiceClubService {
        private val _rooms = MutableStateFlow<List<VoiceClubRoom>>(emptyList())
        val rooms: StateFlow<List<VoiceClubRoom>> = _rooms.asStateFlow()

        init {
            _rooms.value = listOf(
                VoiceClubRoom(
                    id = "club_1",
                    title = "🚀 Android Tech & Jetpack Future",
                    hostName = "Sarah Jenkins",
                    hostAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
                    category = "Technology",
                    activeListeners = 142
                ),
                VoiceClubRoom(
                    id = "club_2",
                    title = "🎧 Late Night Chill & Music Vibe",
                    hostName = "Liam Thompson",
                    hostAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
                    category = "Music",
                    activeListeners = 84
                ),
                VoiceClubRoom(
                    id = "club_3",
                    title = "💡 Startups, Business & Marketing",
                    hostName = "Clara Evans",
                    hostAvatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200",
                    category = "Business",
                    activeListeners = 210
                )
            )
        }

        fun joinClub(roomId: String) {
            _rooms.value = _rooms.value.map { room ->
                if (room.id == roomId) {
                    room.copy(
                        isJoined = !room.isJoined,
                        activeListeners = if (room.isJoined) room.activeListeners - 1 else room.activeListeners + 1
                    )
                } else {
                    room.copy(isJoined = false) // only join one at a time
                }
            }
        }
    }

    // --- Data Saved Tracker State ---
    object DataSavedTracker {
        private val _savedDataMegaBytes = MutableStateFlow(3.34)
        val savedDataMegaBytes: StateFlow<Double> = _savedDataMegaBytes.asStateFlow()

        fun incrementSavedData(amountMb: Double = 0.05) {
            _savedDataMegaBytes.value = (_savedDataMegaBytes.value + amountMb)
        }

        fun resetSavedData() {
            _savedDataMegaBytes.value = 0.0
        }
    }
}
